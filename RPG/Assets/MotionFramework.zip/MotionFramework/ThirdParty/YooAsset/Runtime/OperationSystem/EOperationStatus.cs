﻿
namespace YooAsset
{
	public enum EOperationStatus
	{
		None,
		Succeed,
		Failed
	}
}