﻿using System;
using System.Collections;
using System.Collections.Generic;

/*
namespace YooAsset
{
	internal class WebPlayModeImpl : IBundleServices
	{
	}
}
*/