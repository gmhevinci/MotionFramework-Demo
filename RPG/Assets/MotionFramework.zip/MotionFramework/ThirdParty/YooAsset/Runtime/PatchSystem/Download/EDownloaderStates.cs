﻿
namespace YooAsset
{
	/// <summary>
	/// 下载状态
	/// </summary>
	public enum EDownloaderStates
	{
		None,
		Loading,
		Failed,
		Succeed,
	}
}