﻿
namespace YooAsset
{
	public interface IAssetInstance
	{
	}
}
