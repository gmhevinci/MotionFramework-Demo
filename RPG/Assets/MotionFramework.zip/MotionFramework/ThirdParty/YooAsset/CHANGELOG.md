# CHANGELOG

All notable changes to this package will be documented in this file.   

## [0.0.1-preview] - 2022-00-00
*Compatible with Unity 2018.4*
